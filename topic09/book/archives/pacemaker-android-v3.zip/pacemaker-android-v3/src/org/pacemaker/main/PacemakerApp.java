package org.pacemaker.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.pacemaker.models.Activity;
import org.pacemaker.models.User;

import android.app.Application;
import android.util.Log;

public class PacemakerApp extends Application
{
  private List<Activity>    activities = new ArrayList<Activity>();
  private Map<String, User> users      = new HashMap<String, User>();
  private User              loggedInUser;
  
  public void registerUser(User user)
  {
    users.put(user.email, user);
  }
  
  public boolean loginUser(String email, String password)
  {
    loggedInUser = users.get(email);
    if (loggedInUser != null && !loggedInUser.password.equals(password))
    {
      loggedInUser = null;
    }
    return loggedInUser != null;
  }
  
  public void createActivity (Activity activity)
  {
    activities.add(activity);
  }
  
  public List<Activity> getActivities()
  {
    return activities;
  }
  
  @Override
  public void onCreate()
  {
    super.onCreate();
    Log.v("Pacemaker", "Pacemaker App Started");
  }
}
