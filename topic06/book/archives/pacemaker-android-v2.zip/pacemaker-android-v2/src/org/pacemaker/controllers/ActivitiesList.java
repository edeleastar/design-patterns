package org.pacemaker.controllers;

import java.util.List;
import org.pacemaker.R;
import org.pacemaker.main.PacemakerApp;
import org.pacemaker.models.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;


public class ActivitiesList extends  android.app.Activity
{
  private PacemakerApp app;
  private ListView     activitiesListView;
  
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activities_list);
    
    app = (PacemakerApp) getApplication();

    activitiesListView = (ListView) findViewById(R.id.activitiesListView);

    List<Activity> activities  = app.actvities;
    
    ActivityAdapter activitiesAdapter = new ActivityAdapter(this,  activities);
    activitiesListView.setAdapter(activitiesAdapter);
    activitiesAdapter.notifyDataSetChanged();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu)
  {
    getMenuInflater().inflate(R.menu.activities_list, menu);
    return true;
  }
}

class ActivityAdapter extends ArrayAdapter<Activity>
{
  private Context        context;
  public  List<Activity> activities;

  public ActivityAdapter(Context context, List<Activity> activities)
  {
    super(context, R.layout.activity_row_layout, activities);
    this.context   = context;
    this.activities = activities;
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent)
  {
    LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
 
    View     view      = inflater.inflate(R.layout.activity_row_layout, parent, false);
    Activity activity  = activities.get(position);
    TextView type      = (TextView) view.findViewById(R.id.type);
    TextView location  = (TextView) view.findViewById(R.id.location);
    TextView distance  = (TextView) view.findViewById(R.id.distance);
    
    type.setText(activity.type);
    location.setText(activity.location);
    distance.setText("" + activity.distance);
    return view;
  }

  @Override
  public int getCount()
  {
    return activities.size();
  }
}