package org.pacemaker.main;

import java.util.ArrayList;
import java.util.List;

import org.pacemaker.models.Activity;

import android.app.Application;
import android.util.Log;

public class PacemakerApp extends Application
{
  public List<Activity> actvities = new ArrayList<Activity>();
  
  @Override
  public void onCreate()
  {
    super.onCreate();
    Log.v("Pacemaker", "Pacemaker App Started");
  }
}
