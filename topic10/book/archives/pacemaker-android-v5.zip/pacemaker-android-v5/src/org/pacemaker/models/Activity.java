package org.pacemaker.models;

public class Activity 
{
  public Long id;
  public String kind;
  public String location;
  public double distance;

  public Activity()
  {}
  
  public Activity(String type, String location, double distance)
  {
    this.kind      = type;
    this.location  = location;
    this.distance  = distance;
  }
}